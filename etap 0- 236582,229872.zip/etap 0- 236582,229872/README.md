# Concurrent programming

## Working Group

| Name Surname (initials) | GUID                                     |
| ----------------------- | ---------------------------------------- |
| Tomasz Lesiak           | `{B966FB18-45C5-4C84-86E9-12E47C4161CC}` |
| Bartłomiej Dygasiński   | `{FED9070B-306C-46A0-B838-C4937392CC2E}` |
