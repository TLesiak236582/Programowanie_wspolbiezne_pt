using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestProject2
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMultiplication2()
        {
            Assert.AreNotEqual(4,Wsp�bie�ne.Program.multiplication(2, 3));
        }
    }
}